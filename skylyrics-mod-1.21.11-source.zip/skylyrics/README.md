# Sky Lyrics (Fabric, Minecraft 1.21.11, client-side)

Shows the synced lyrics of the Spotify song you're playing floating in the sky.
Lyrics come from LRCLIB at runtime; nothing is bundled.

## Build the jar
Option A (local): install JDK 25 (Temurin, adoptium.net), open a terminal in this folder, run
    gradlew build        (Windows)   |   ./gradlew build   (Mac/Linux)
The jar is build/libs/skylyrics-0.1.0.jar (not the -sources one).

Option B (no Java install): upload this folder to a new GitHub repo. The included
workflow builds it; download the jar from Actions -> latest run -> Artifacts.

## Use
1. mods folder: the jar + Fabric API (0.141.6+1.21.11 or newer), Fabric Loader for 1.21.11.
2. Spotify dashboard app, redirect URI http://127.0.0.1:8888/callback; paste Client ID in config/skylyrics.json
3. In game: /lyrics login

Font: put your .ttf at src/main/resources/assets/skylyrics/font/lyric.ttf before building.
