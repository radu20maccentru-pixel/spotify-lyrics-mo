package dev.skylyrics;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Consumer;
import java.util.stream.Collectors;

/** Spotify "currently playing" poller using the Authorization Code + PKCE flow (no client secret needed). */
public final class Spotify {
    public record State(String trackId, boolean playing, long progressMs, long stampMs, List<Lrclib.Line> lyrics) {
        public long positionMs() {
            return playing ? progressMs + (System.currentTimeMillis() - stampMs) : progressMs;
        }
    }

    private static final String REDIRECT = "http://127.0.0.1:8888/callback";
    private static final Gson GSON = new Gson();

    private final HttpClient http = HttpClient.newHttpClient();
    private final Path cfgFile = FabricLoader.getInstance().getConfigDir().resolve("skylyrics.json");
    private JsonObject cfg = new JsonObject();
    private String accessToken;
    private long accessExpiresAt;
    private volatile State state;
    private final Map<String, List<Lrclib.Line>> cache = new ConcurrentHashMap<>();
    private final Set<String> fetching = ConcurrentHashMap.newKeySet();
    private final ExecutorService worker = Executors.newCachedThreadPool(r -> {
        Thread t = new Thread(r, "skylyrics-worker");
        t.setDaemon(true);
        return t;
    });

    public Spotify() {
        load();
        ScheduledExecutorService ex = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "skylyrics-poll");
            t.setDaemon(true);
            return t;
        });
        ex.scheduleWithFixedDelay(this::poll, 2, 2, TimeUnit.SECONDS);
    }

    public State state() { return state; }

    // ---------------------------------------------------------------- config

    private void load() {
        try {
            if (Files.exists(cfgFile)) {
                cfg = JsonParser.parseString(Files.readString(cfgFile)).getAsJsonObject();
            } else {
                cfg.addProperty("clientId", "");
                save();
            }
        } catch (Exception ignored) {}
    }

    private void save() {
        try { Files.writeString(cfgFile, GSON.toJson(cfg)); } catch (Exception ignored) {}
    }

    private static String str(JsonObject o, String k) {
        JsonElement e = o.get(k);
        return (e == null || e.isJsonNull() || e.getAsString().isBlank()) ? null : e.getAsString();
    }

    public Path configPath() { return cfgFile; }

    public void logout() {
        cfg.remove("refreshToken");
        accessToken = null;
        state = null;
        save();
    }

    // ---------------------------------------------------------------- auth

    public void login(Consumer<String> say, Consumer<String> link) {
        load();
        String cid = str(cfg, "clientId");
        if (cid == null) {
            say.accept("Put your Spotify Client ID in " + cfgFile + " first, then run /lyrics login again.");
            return;
        }
        worker.submit(() -> {
            ServerSocket srv = null;
            try {
                byte[] b = new byte[64];
                new SecureRandom().nextBytes(b);
                String verifier = Base64.getUrlEncoder().withoutPadding().encodeToString(b);
                String challenge = Base64.getUrlEncoder().withoutPadding().encodeToString(
                        MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(StandardCharsets.US_ASCII)));

                // Plain socket instead of com.sun.net.httpserver: Minecraft's bundled Java lacks that module.
                srv = new ServerSocket(8888, 5, InetAddress.getByName("127.0.0.1"));
                srv.setSoTimeout(5000);

                String url = "https://accounts.spotify.com/authorize?response_type=code"
                        + "&client_id=" + enc(cid)
                        + "&redirect_uri=" + enc(REDIRECT)
                        + "&scope=" + enc("user-read-currently-playing user-read-playback-state")
                        + "&code_challenge_method=S256&code_challenge=" + challenge;
                say.accept("Opening your browser to log in to Spotify...");
                link.accept(url);
                openBrowser(url);

                String c = waitForCode(srv);
                Map<String, String> form = new LinkedHashMap<>();
                form.put("grant_type", "authorization_code");
                form.put("code", c);
                form.put("redirect_uri", REDIRECT);
                form.put("client_id", cid);
                form.put("code_verifier", verifier);
                JsonObject j = post(form);
                if (j == null) { say.accept("Spotify login failed (token exchange)."); return; }
                applyToken(j);
                say.accept("Spotify connected. Play a song!");
            } catch (Throwable e) {
                say.accept("Spotify login failed: " + e);
            } finally {
                try { if (srv != null) srv.close(); } catch (Exception ignored) {}
            }
        });
    }

    private static String waitForCode(ServerSocket srv) throws Exception {
        long end = System.currentTimeMillis() + 180_000;
        while (System.currentTimeMillis() < end) {
            try (Socket s = srv.accept()) {
                s.setSoTimeout(5000);
                BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
                String line = in.readLine(); // e.g. GET /callback?code=... HTTP/1.1
                if (line == null) continue;
                String[] parts = line.split(" ");
                String target = parts.length > 1 ? parts[1] : "";
                int qi = target.indexOf('?');
                Map<String, String> q = query(qi >= 0 ? target.substring(qi + 1) : null);
                byte[] page = "<html><body style='font-family:sans-serif;text-align:center;margin-top:20vh'><h2>Sky Lyrics connected. You can close this tab.</h2></body></html>"
                        .getBytes(StandardCharsets.UTF_8);
                OutputStream out = s.getOutputStream();
                out.write(("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: "
                        + page.length + "\r\nConnection: close\r\n\r\n").getBytes(StandardCharsets.UTF_8));
                out.write(page);
                out.flush();
                if (q.containsKey("code")) return q.get("code");
                if (q.containsKey("error")) throw new RuntimeException(q.get("error"));
            } catch (SocketTimeoutException ignored) {
                // keep waiting
            }
        }
        throw new RuntimeException("timed out waiting for the browser");
    }

    private static void openBrowser(String url) {
        try {
            String os = System.getProperty("os.name", "").toLowerCase();
            if (os.contains("win")) new ProcessBuilder("rundll32", "url.dll,FileProtocolHandler", url).start();
            else if (os.contains("mac")) new ProcessBuilder("open", url).start();
            else new ProcessBuilder("xdg-open", url).start();
        } catch (Exception ignored) {}
    }

    private static String enc(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }

    private static Map<String, String> query(String raw) {
        Map<String, String> m = new HashMap<>();
        if (raw == null) return m;
        for (String p : raw.split("&")) {
            int i = p.indexOf('=');
            if (i > 0) m.put(URLDecoder.decode(p.substring(0, i), StandardCharsets.UTF_8),
                    URLDecoder.decode(p.substring(i + 1), StandardCharsets.UTF_8));
        }
        return m;
    }

    private JsonObject post(Map<String, String> form) throws Exception {
        String body = form.entrySet().stream()
                .map(e -> enc(e.getKey()) + "=" + enc(e.getValue()))
                .collect(Collectors.joining("&"));
        HttpRequest req = HttpRequest.newBuilder(URI.create("https://accounts.spotify.com/api/token"))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString(body)).build();
        HttpResponse<String> res = http.send(req, HttpResponse.BodyHandlers.ofString());
        return res.statusCode() == 200 ? JsonParser.parseString(res.body()).getAsJsonObject() : null;
    }

    private synchronized void applyToken(JsonObject j) {
        accessToken = j.get("access_token").getAsString();
        accessExpiresAt = System.currentTimeMillis() + (j.get("expires_in").getAsLong() - 60) * 1000L;
        if (j.has("refresh_token")) cfg.addProperty("refreshToken", j.get("refresh_token").getAsString());
        save();
    }

    private synchronized String token() throws Exception {
        if (accessToken != null && System.currentTimeMillis() < accessExpiresAt) return accessToken;
        String rt = str(cfg, "refreshToken"), cid = str(cfg, "clientId");
        if (rt == null || cid == null) return null;
        Map<String, String> form = new LinkedHashMap<>();
        form.put("grant_type", "refresh_token");
        form.put("refresh_token", rt);
        form.put("client_id", cid);
        JsonObject j = post(form);
        if (j == null) return null;
        applyToken(j);
        return accessToken;
    }

    // ---------------------------------------------------------------- polling

    private void poll() {
        try {
            String token = token();
            if (token == null) { state = null; return; }
            long sent = System.currentTimeMillis();
            HttpRequest req = HttpRequest.newBuilder(URI.create("https://api.spotify.com/v1/me/player/currently-playing"))
                    .header("Authorization", "Bearer " + token).GET().build();
            HttpResponse<String> res = http.send(req, HttpResponse.BodyHandlers.ofString());
            long stamp = (sent + System.currentTimeMillis()) / 2; // compensate for request latency
            int code = res.statusCode();
            if (code == 401) { accessToken = null; return; }
            if (code != 200) { state = null; return; }

            JsonObject o = JsonParser.parseString(res.body()).getAsJsonObject();
            JsonElement itemEl = o.get("item");
            if (itemEl == null || itemEl.isJsonNull()) { state = null; return; }
            JsonObject item = itemEl.getAsJsonObject();

            String name = item.get("name").getAsString();
            String artist = item.getAsJsonArray("artists").get(0).getAsJsonObject().get("name").getAsString();
            String album = item.has("album") ? item.getAsJsonObject("album").get("name").getAsString() : "";
            int durSec = (int) Math.round(item.get("duration_ms").getAsLong() / 1000.0);
            String id = str(item, "id");
            if (id == null) id = name + "|" + artist;
            boolean playing = o.has("is_playing") && o.get("is_playing").getAsBoolean();
            long progress = o.has("progress_ms") && !o.get("progress_ms").isJsonNull() ? o.get("progress_ms").getAsLong() : 0;

            if (!cache.containsKey(id) && fetching.add(id)) {
                final String fid = id;
                worker.submit(() -> {
                    try { cache.put(fid, Lrclib.fetch(http, name, artist, album, durSec)); }
                    finally { fetching.remove(fid); }
                });
            }
            state = new State(id, playing, progress, stamp, cache.getOrDefault(id, List.of()));
        } catch (Throwable ignored) {
            // network hiccup: keep last state
        }
    }
}
