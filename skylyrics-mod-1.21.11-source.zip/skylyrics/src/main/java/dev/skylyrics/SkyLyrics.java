package dev.skylyrics;

import com.mojang.blaze3d.vertex.PoseStack;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FontDescription;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.Identifier;
import net.minecraft.world.phys.Vec3;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class SkyLyrics implements ClientModInitializer {
    // ---- tweak these ----
    static final float LIFE_SECONDS = 4.5f;   // how long a line stays up
    static final float DISTANCE = 30f;        // blocks in front of you
    static final float SCALE = 0.45f;         // text size
    static final int MAX_CHARS_PER_ROW = 22;
    static final boolean BOLD = true;
    static final boolean FLIP_X = false;      // set true if the text shows up mirrored
    // ---------------------

    static final Identifier FONT = Identifier.fromNamespaceAndPath("skylyrics", "lyric");

    private final Spotify spotify = new Spotify();
    private final List<SkyLine> active = new ArrayList<>();
    private final Random rng = new Random();
    private boolean enabled = true;
    private String lastTrack = "";
    private int lastIdx = -1;

    /** A lyric line floating in a fixed compass direction around you (follows you, ignores where you look). */
    private record SkyLine(List<String> rows, Vec3 dir, Vec3 side, float sideOffset, float height, long bornMs) {}

    @Override
    public void onInitializeClient() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> dispatcher.register(
                ClientCommandManager.literal("lyrics")
                        .then(ClientCommandManager.literal("login").executes(c -> {
                            spotify.login(this::say, this::sayLink);
                            return 1;
                        }))
                        .then(ClientCommandManager.literal("logout").executes(c -> {
                            spotify.logout();
                            say("Logged out of Spotify.");
                            return 1;
                        }))
                        .then(ClientCommandManager.literal("toggle").executes(c -> {
                            enabled = !enabled;
                            if (!enabled) active.clear();
                            say("Sky Lyrics " + (enabled ? "ON" : "OFF"));
                            return 1;
                        }))
                        .then(ClientCommandManager.literal("config").executes(c -> {
                            say("Config: " + spotify.configPath());
                            return 1;
                        }))
        ));

        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        WorldRenderEvents.AFTER_ENTITIES.register(this::render);
    }

    private void say(String msg) {
        Minecraft mc = Minecraft.getInstance();
        mc.execute(() -> {
            if (mc.player != null) mc.player.displayClientMessage(Component.literal("[Sky Lyrics] " + msg), false);
        });
    }

    private void sayLink(String url) {
        Minecraft mc = Minecraft.getInstance();
        mc.execute(() -> {
            if (mc.player == null) return;
            Component link = Component.literal("[click here if the browser didn't open]")
                    .withStyle(Style.EMPTY.withClickEvent(new ClickEvent.OpenUrl(URI.create(url))).withUnderlined(true));
            mc.player.displayClientMessage(link, false);
        });
    }

    private void tick(Minecraft mc) {
        long now = System.currentTimeMillis();
        active.removeIf(l -> now - l.bornMs() > LIFE_SECONDS * 1000);
        if (!enabled || mc.player == null) return;

        Spotify.State s = spotify.state();
        if (s == null || s.lyrics().isEmpty()) return;
        if (!s.trackId().equals(lastTrack)) { lastTrack = s.trackId(); lastIdx = -1; active.clear(); }
        if (!s.playing()) return;

        long pos = s.positionMs();
        List<Lrclib.Line> lines = s.lyrics();
        int idx = -1;
        for (int i = 0; i < lines.size(); i++) {
            if (lines.get(i).timeMs() <= pos) idx = i; else break;
        }
        if (idx == lastIdx) return;
        lastIdx = idx;
        if (idx < 0) return;
        String text = lines.get(idx).text();
        if (text.isBlank()) return;

        Vec3 dir = Vec3.directionFromRotation(0f, mc.player.getYRot());
        Vec3 side = new Vec3(-dir.z, 0, dir.x);
        active.add(new SkyLine(wrap(text), dir, side, (rng.nextFloat() - 0.5f) * 16f, 8f + rng.nextFloat() * 8f, now));
    }

    private static List<String> wrap(String text) {
        List<String> rows = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String w : text.split("\\s+")) {
            if (cur.length() > 0 && cur.length() + 1 + w.length() > MAX_CHARS_PER_ROW) {
                rows.add(cur.toString());
                cur.setLength(0);
            }
            if (cur.length() > 0) cur.append(' ');
            cur.append(w);
        }
        if (cur.length() > 0) rows.add(cur.toString());
        return rows;
    }

    private void render(WorldRenderContext ctx) {
        if (!enabled || active.isEmpty()) return;
        PoseStack ps = ctx.matrices();
        MultiBufferSource buffers = ctx.consumers();
        if (ps == null || buffers == null) return;

        var cam = ctx.worldState().cameraRenderState;
        Vec3 cp = cam.pos;
        Font font = Minecraft.getInstance().font;
        long now = System.currentTimeMillis();

        for (SkyLine l : active) {
            float age = (now - l.bornMs()) / 1000f;
            float alpha = age < 0.25f ? age / 0.25f : (age > LIFE_SECONDS - 1f ? LIFE_SECONDS - age : 1f);
            int a = (int) (Math.max(0f, Math.min(1f, alpha)) * 255);
            if (a < 8) continue; // the game treats very low alpha as opaque

            Vec3 p = cp.add(l.dir().scale(DISTANCE)).add(l.side().scale(l.sideOffset())).add(0, l.height(), 0);

            ps.pushPose();
            ps.translate(p.x - cp.x, p.y - cp.y, p.z - cp.z);
            ps.mulPose(cam.orientation);               // billboard: face the camera
            ps.scale(FLIP_X ? -SCALE : SCALE, -SCALE, SCALE);

            float totalH = l.rows().size() * 10f;
            for (int i = 0; i < l.rows().size(); i++) {
                Style style = Style.EMPTY.withFont(new FontDescription.Resource(FONT)).withBold(BOLD);
                Component c = Component.literal(l.rows().get(i)).withStyle(style);
                float w = font.width(c);
                font.drawInBatch(c, -w / 2f, i * 10f - totalH / 2f, (a << 24) | 0xFFFFFF, false,
                        ps.last().pose(), buffers, Font.DisplayMode.SEE_THROUGH, 0, 0xF000F0);
            }
            ps.popPose();
        }
    }
}
