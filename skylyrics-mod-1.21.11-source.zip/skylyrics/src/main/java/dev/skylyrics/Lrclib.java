package dev.skylyrics;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Fetches time-synced lyrics at runtime from LRCLIB (https://lrclib.net). Nothing is bundled in the mod. */
public final class Lrclib {
    public record Line(long timeMs, String text) {}

    private static final Pattern TS = Pattern.compile("^\\[(\\d+):(\\d+)(?:[.:](\\d+))?]\\s*(.*)$");

    private static String enc(String s) { return URLEncoder.encode(s == null ? "" : s, StandardCharsets.UTF_8); }

    private static String get(HttpClient http, String url) {
        try {
            HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                    .header("User-Agent", "SkyLyrics Minecraft mod (Fabric)")
                    .GET().build();
            HttpResponse<String> res = http.send(req, HttpResponse.BodyHandlers.ofString());
            return res.statusCode() == 200 ? res.body() : null;
        } catch (Exception e) {
            return null;
        }
    }

    public static List<Line> fetch(HttpClient http, String track, String artist, String album, int durationSec) {
        String body = get(http, "https://lrclib.net/api/get?track_name=" + enc(track) + "&artist_name=" + enc(artist)
                + "&album_name=" + enc(album) + "&duration=" + durationSec);
        if (body != null) {
            List<Line> l = parse(JsonParser.parseString(body).getAsJsonObject());
            if (!l.isEmpty()) return l;
        }
        body = get(http, "https://lrclib.net/api/search?track_name=" + enc(track) + "&artist_name=" + enc(artist));
        if (body != null) {
            JsonArray arr = JsonParser.parseString(body).getAsJsonArray();
            for (JsonElement e : arr) {
                List<Line> l = parse(e.getAsJsonObject());
                if (!l.isEmpty()) return l;
            }
        }
        return List.of();
    }

    private static List<Line> parse(JsonObject o) {
        JsonElement synced = o.get("syncedLyrics");
        if (synced == null || synced.isJsonNull()) return List.of();
        List<Line> out = new ArrayList<>();
        for (String raw : synced.getAsString().split("\\R")) {
            Matcher m = TS.matcher(raw.trim());
            if (!m.matches()) continue;
            long ms = Long.parseLong(m.group(1)) * 60_000L + Long.parseLong(m.group(2)) * 1000L;
            String frac = m.group(3);
            if (frac != null) {
                ms += frac.length() == 2 ? Long.parseLong(frac) * 10 : Long.parseLong((frac + "00").substring(0, 3));
            }
            out.add(new Line(ms, m.group(4).trim()));
        }
        return out;
    }
}
